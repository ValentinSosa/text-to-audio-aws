import boto3

# Clientes AWS
s3 = boto3.client("s3")
polly = boto3.client("polly")

def lambda_handler(event, context):
    # 1️⃣ Obtener archivo subido
    record = event['Records'][0]
    bucket = record['s3']['bucket']['name']
    key = record['s3']['object']['key']

    print(f"Archivo recibido: s3://{bucket}/{key}")

    # 2️⃣ Descargar archivo desde Input Bucket
    file_obj = s3.get_object(Bucket=bucket, Key=key)
    text = file_obj['Body'].read().decode('utf-8')

    # 3️⃣ Generar audio con Polly
    response = polly.synthesize_speech(
        Text=text,
        OutputFormat='mp3',
        VoiceId='Joanna'
    )

    # 4️⃣ Guardar archivo de audio en Output Bucket
    output_bucket = "text-to-audio-aws-output-c38cb20c"  # reemplazá con tu bucket real
    audio_key = key.replace(".txt", ".mp3")

    s3.put_object(
        Bucket=output_bucket,
        Key=audio_key,
        Body=response['AudioStream'].read()
    )

    print(f"Archivo de audio generado: s3://{output_bucket}/{audio_key}")

    return {
        'statusCode': 200,
        'body': f"Archivo de audio generado: {audio_key}"
    }
